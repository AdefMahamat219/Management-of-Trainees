package com.quamtechs.stagiaire.entities;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.quamtechs.stagiaire.enumerations.StatutStagiaire;
import com.quamtechs.stagiaire.enumerations.TypeStage;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document
public class Stagiaire{
    @Id
    private String idStagiaire;
    private String nom;
    private String prenom;
    private String idEncadreur;
    private LocalDate dateInscrip;
    private LocalDate dateNaissance;
    //private String password;
    private String lieuNaissance;
    private String filiere;
    private String etablissement;
    private String email;
    private String numTel;
    private StatutStagiaire statutStagiaire;
    private TypeStage typeStage;
}

