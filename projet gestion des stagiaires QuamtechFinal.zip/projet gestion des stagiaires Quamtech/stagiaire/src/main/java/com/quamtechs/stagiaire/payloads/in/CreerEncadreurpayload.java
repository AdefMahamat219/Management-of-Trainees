package com.quamtechs.stagiaire.payloads.in;

import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Document
public class CreerEncadreurpayload {
    @NotNull(message = "le nom est requis !!")
    private String nomEncadreur;

    @NotNull(message = "le prenom est requis !!")
    private String prenomEncadreur;

    @NotNull(message = "la fonction est requise !!")
    private String specialite;

    @NotNull(message = "le contact est requis !!")
    private String telEncadreur;

    @NotNull(message = "le mail est requis !!")
    private String emailEncadreur;

    @NotNull(message = "le mot de passe est requis !!")
    private String password;
    
}
