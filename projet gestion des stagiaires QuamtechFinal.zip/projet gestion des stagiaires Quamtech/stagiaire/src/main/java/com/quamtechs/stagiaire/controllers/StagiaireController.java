package com.quamtechs.stagiaire.controllers;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quamtechs.stagiaire.entities.Stagiaire;
import com.quamtechs.stagiaire.enumerations.StatutStagiaire;
import com.quamtechs.stagiaire.exceptions.GestionStagexception;
import com.quamtechs.stagiaire.payloads.in.CreerStagiairePayload;
import com.quamtechs.stagiaire.payloads.in.EditStagiairePayload;
import com.quamtechs.stagiaire.services.StagiaireServices;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;


@RestController
@AllArgsConstructor
@CrossOrigin("*")
@RequestMapping(value = "/stagiaire")
public class StagiaireController {
    private final StagiaireServices stagiaireServices;

    @PostMapping(value = "/creerStagiare")
    public ResponseEntity<Stagiaire> créerStagiaire(@Valid @RequestBody CreerStagiairePayload creerStagiairePayload ) throws GestionStagexception{
        var stagiaire = stagiaireServices.creerStagiaire(creerStagiairePayload);
        return new ResponseEntity<Stagiaire>(stagiaire, HttpStatus.CREATED);
    }

    @GetMapping(value = "/findAllStagNonTraiter")
    public ResponseEntity<List<Stagiaire>> findAllStagNonTraiter() throws GestionStagexception {
      return ResponseEntity.ok(stagiaireServices.stagiairesNonTraiter());
    }

    @GetMapping(value = "/findAllStagAdmis")
    public ResponseEntity<List<Stagiaire>> findAllStagAdmis() throws GestionStagexception {
      return ResponseEntity.ok(stagiaireServices.stagiairesAdmis());
    }

    @DeleteMapping(value = "/supprimerStagiaireById")
    public ResponseEntity<String> supprimerStagiaireById( String idStagiaire) throws GestionStagexception{
        var stagiaire = stagiaireServices.deleteStagiaireById(idStagiaire);
        return new ResponseEntity<String>(stagiaire, HttpStatus.OK);
    }

    @DeleteMapping(value = "/deleteAllStag")
    public ResponseEntity<String> deleteAllStag() throws GestionStagexception{
        var stagiaire = stagiaireServices.deleteAllStag();
        return new ResponseEntity<String>(stagiaire, HttpStatus.OK);
    }

    @GetMapping(value = "/findAllStag")
    public ResponseEntity<List<Stagiaire>> findAllStag() throws GestionStagexception {
      return ResponseEntity.ok(stagiaireServices.listerTousLesStag());
    }

    @GetMapping(value = "/findOneStagiaireById")
    public ResponseEntity<Stagiaire>findOneStagiaireById(String idStagiaire) throws GestionStagexception {
      return ResponseEntity.ok(stagiaireServices.findStagiaireById(idStagiaire));
    }


    @PutMapping("/affecterEncadreurAStagiaire")
    public ResponseEntity<String> affecterEncadreurAStagiaire(String idEncadreur, String idStagiaire) throws GestionStagexception{
        String res = stagiaireServices.setEncad2Stagiaire(idStagiaire, idEncadreur);
        return new ResponseEntity<String>(res, HttpStatus.OK);
    }

    @PutMapping("/changerStatutStagiaire")
        public ResponseEntity<Stagiaire> changerStatutStagiaire(String idStagiaire, StatutStagiaire stagiaire) throws GestionStagexception{
            Stagiaire stg = stagiaireServices.changerStatutStagiaire(idStagiaire, stagiaire);
            return new ResponseEntity<Stagiaire>(stg, HttpStatus.OK);
        }

    @PutMapping("/editStagiaire")
    public ResponseEntity<Stagiaire> editStagiaire(EditStagiairePayload editStagiairePayload, String idStagiaire) throws GestionStagexception{
        Stagiaire res = stagiaireServices.editStagiaire(editStagiairePayload, idStagiaire);
        return new ResponseEntity<Stagiaire>(res, HttpStatus.OK);
    }
}
