package com.quamtechs.stagiaire.services;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.quamtechs.stagiaire.entities.Encadreur;
import com.quamtechs.stagiaire.entities.Stagiaire;
import com.quamtechs.stagiaire.enumerations.StatutStagiaire;
import com.quamtechs.stagiaire.exceptions.EncadreurNonTrouverException;
import com.quamtechs.stagiaire.exceptions.GestionStagexception;
import com.quamtechs.stagiaire.exceptions.MessagingException;
import com.quamtechs.stagiaire.exceptions.MotDePasseIncorrectException;
import com.quamtechs.stagiaire.exceptions.StagiaireNonTrouverException;
import com.quamtechs.stagiaire.exceptions.UtilisateurAvecEmailException;
import com.quamtechs.stagiaire.payloads.in.AuthenticationPayload;
import com.quamtechs.stagiaire.payloads.in.CreerEncadreurpayload;
import com.quamtechs.stagiaire.payloads.in.EditEncadreur;
import com.quamtechs.stagiaire.repositories.EncadreurRepositories;
import com.quamtechs.stagiaire.repositories.StagiaireRepositories;

import jakarta.mail.internet.MimeMessage;
import lombok.AllArgsConstructor;
@Service
@AllArgsConstructor
public class EncadreurServices {
    private final EncadreurRepositories encadreurRepositories;
    private final StagiaireRepositories stagiaireRepositories;
    private final JavaMailSender mailSender;

    public Encadreur creerEncadreur(CreerEncadreurpayload creerEncadreurpayload) throws GestionStagexception, UtilisateurAvecEmailException{

            ArrayList<String> idStag = new ArrayList<>();
            idStag.add(0, " ");
            Encadreur encadreur0 =  encadreurRepositories.findByEmailEncadreur(creerEncadreurpayload.getEmailEncadreur());
            if(encadreur0 != null && encadreurRepositories.existsById(encadreur0.getIdEncadreur()))
            {
                throw new UtilisateurAvecEmailException("L'Email "+creerEncadreurpayload.getEmailEncadreur()+" est deja liée à un utilisateur! ❌");
            }
            else{
                Encadreur encadreur = Encadreur.builder()
                .nomEncadreur(creerEncadreurpayload.getNomEncadreur())
                .specialite(creerEncadreurpayload.getSpecialite())
                .emailEncadreur(creerEncadreurpayload.getEmailEncadreur())
                .prenomEncadreur(creerEncadreurpayload.getPrenomEncadreur())
                .telEncadreur(creerEncadreurpayload.getTelEncadreur())
                .listStag(idStag)
                .password(creerEncadreurpayload.getPassword())
                .idEncadreur(UUID.randomUUID().toString())
                .build();
                return encadreurRepositories.save(encadreur);
                }
      
    }

    public void envoiEmailValidation(String emailStagiaire) throws MessagingException, UnsupportedEncodingException, jakarta.mail.MessagingException, StagiaireNonTrouverException{
        
        Stagiaire stagiaire = stagiaireRepositories.findByEmail(emailStagiaire);
        
        if(stagiaire != null && stagiaireRepositories.existsById(stagiaire.getIdStagiaire()))
        {
            String subject = "MISE A JOUR CONCERNANT VOTRE DEMANDE DE STAGE";
            String senderName = "QUAMTECHS GESTION DES STAGIAIRES";
            String mailContent = "<p> Hi, "+ stagiaire.getNom()+ ", </p>"+
                    "<p>C'est avec joie que nous vous annoncons la retenue de votre Canditure en tant que stagiaire,"+"" +
                    "</p>"+
                    "<a href=\"\">Nous vous ferons parvenir les details neccessaire au deroulement de votre stage chez nous.</a>"+
                    "<p> Merci! <br> Coordialement, Kouekam Yann remplacant de Mr. Nyassi Loic";
            MimeMessage message = mailSender.createMimeMessage();
            var messageHelper = new MimeMessageHelper(message);
            messageHelper.setFrom("adefmahamat656@gmail.com", senderName);
            messageHelper.setTo(stagiaire.getEmail());
            messageHelper.setSubject(subject);
            messageHelper.setText(mailContent, true);
            mailSender.send(message);

            stagiaire.setStatutStagiaire(StatutStagiaire.ACCEPTE);
            stagiaireRepositories.save(stagiaire);
        }else {
            throw new StagiaireNonTrouverException("Le stagiaire avec l'email "+emailStagiaire+" n'existe pas");
        }

      System.out.println("Email envoyéééé Accepter");
      System.out.println("Email envoyéééé Accepter");
      System.out.println("Email envoyéééé Accepter");
      System.out.println("Email envoyéééé Accepter");
      System.out.println("Email envoyéééé Accepter");
      System.out.println("Email envoyéééé Accepter");
    }

    public void envoiEmailRefuser(String emailStagiaire) throws MessagingException, UnsupportedEncodingException, jakarta.mail.MessagingException, StagiaireNonTrouverException{
        
        Stagiaire stagiaire = stagiaireRepositories.findByEmail(emailStagiaire);
        
        if(stagiaire != null && stagiaireRepositories.existsById(stagiaire.getIdStagiaire()))
        {
            String subject = "MISE A JOUR CONCERNANT VOTRE DEMANDE DE STAGE";
            String senderName = "QUAMTECHS GESTION DES STAGIAIRES";
            String mailContent = "<p> Hi, "+ stagiaire.getNom()+ ", </p>"+
                    "<p>Merci pour l'interet que vous porter à faire un stage chez QuamTechs,"+"" +
                    "</p>"+
                    "<a href=\"\">Malheureusement vous n'avez pas été retenues parmis nos candidats.</a>"+
                    "<p> Merci! <br> Coordialement, Kouekam Yann remplacant de Mr. Nyassi Loic";
            MimeMessage message = mailSender.createMimeMessage();
            var messageHelper = new MimeMessageHelper(message);
            messageHelper.setFrom("adefmahamat656@gmail.com", senderName);
            messageHelper.setTo(stagiaire.getEmail());
            messageHelper.setSubject(subject);
            messageHelper.setText(mailContent, true);
            mailSender.send(message);
            stagiaire.setStatutStagiaire(StatutStagiaire.REFUSE);
            stagiaireRepositories.save(stagiaire);
        }else {
            throw new StagiaireNonTrouverException("Le stagiaire avec l'email "+emailStagiaire+" n'existe pas");
        }

      System.out.println("Email envoyéééé Refuser");
      System.out.println("Email envoyéééé Refuser");
      System.out.println("Email envoyéééé Refuser");
      System.out.println("Email envoyéééé Refuser");
      System.out.println("Email envoyéééé Refuser");
      System.out.println("Email envoyéééé Refuser");
    }

    public String authentificationManuelle(AuthenticationPayload authenticationPayload ) throws MotDePasseIncorrectException, EncadreurNonTrouverException
    {
        Encadreur encadreur = encadreurRepositories.findByEmailEncadreur(authenticationPayload.getEmailEncadreur());
        if(encadreur != null && encadreurRepositories.existsById(encadreur.getIdEncadreur()))
        {
            if(authenticationPayload.getPassword().equals(encadreur.getPassword()))
            {
                return "Authentication reuissi ✅";
            }
            else{
                throw new MotDePasseIncorrectException("Mot de passe incorrect ❌, Veuillez reessayer! ↻");
            }
        }
        else{
            throw new EncadreurNonTrouverException("Aucun encadreur avec cet adresse email n'existe ❌, veuillez ressayer! ↻");
        }
    }

    public String deleteEncadreurById(String id) throws GestionStagexception{
        var test = encadreurRepositories.existsById(id);
        if (test) {
            encadreurRepositories.deleteById(id);
            return "l'encadreur avec pour id : "+id+" a été supprimé !!";
        } else {
            throw new GestionStagexception(500,"encadreur inexistant !!");
        } 
    }


    public Encadreur findEncadreurById(String id) throws GestionStagexception{
        boolean test = encadreurRepositories.existsById(id);
        if (test) {
            Encadreur enc = encadreurRepositories.findById(id).get();
            return enc;
        } else {
            throw new GestionStagexception(500,"encadreur inexistant !!");
        } 
    }

    public ArrayList<String> findAllStagEncById(String id) throws GestionStagexception{
        var test = encadreurRepositories.existsById(id);
        if (test) {
            Encadreur enc = encadreurRepositories.findById(id).get();
            var list = new ArrayList<String>();
            for (String object : enc.getListStag()) {
                list.add(object);
            }
            return list;
        } else {
            throw new GestionStagexception(500,"encadreur inexistant !!");
        } 
    }



    public Encadreur editEnc(EditEncadreur editEncadreur, String id) throws GestionStagexception{
        try {
            Encadreur enc = findEncadreurById(id);
            enc.setEmailEncadreur(editEncadreur.getEmailEncadreur());
            enc.setSpecialite(editEncadreur.getSpecialite());
            enc.setNomEncadreur(editEncadreur.getNomEncadreur());
            enc.setPrenomEncadreur(editEncadreur.getPrenomEncadreur());
            enc.setTelEncadreur(editEncadreur.getTelEncadreur());
            return encadreurRepositories.save(enc);
        } catch (Exception e) {
            throw new GestionStagexception(500,"erreur survenue lors de la modification de l'encadreur !!");
        }
    }

    public List<Encadreur>listerTousLesEnc() throws GestionStagexception{
         var liste = encadreurRepositories.findAll();
         if (liste.toString()=="[]") {
            throw new GestionStagexception(500,"aucun encadreur trouvé !!");
         } else {
            return liste;
         }
    }

    public String deleteAllEnc() throws GestionStagexception{
        var enc = encadreurRepositories.findAll();
        if (enc == null||enc.isEmpty()||enc.contains(null)) {
            throw new GestionStagexception(500,"aucun encadreur trouvé !!");
        } else {
            encadreurRepositories.deleteAll();
            return "tous les encadreurs ont été supprimés !! ";
        }
    }
}
