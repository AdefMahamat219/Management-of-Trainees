package com.quamtechs.stagiaire.payloads.in;

import java.time.LocalDate;

import org.springframework.data.mongodb.core.mapping.Document;

import com.quamtechs.stagiaire.enumerations.TypeStage;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Document
public class CreerStagiairePayload {
    @NotNull(message = "le nom est requis !!")
    private String nom;

    @NotNull(message = "le prenom est requis !!")
    private String prenom;

    @NotNull(message = "la date de naissance est requise !!")
    private LocalDate dateNaissance;

    @NotNull(message = "le lieu de naissance est requis !!")
    private String lieuNaissance;

    @NotNull(message = "la filiere est requise !!")
    private String filiere;

    @NotNull(message = "l'etablissement est requis !!")
    private String etablissement;

    @NotNull(message = "le mail est requis !!")
    private String email;

    @NotNull(message = "le numero de telephione est requis !!")
    private String numTel;

    @NotNull(message = "le type de stage est requis !!")
    private TypeStage typeStage;
}
