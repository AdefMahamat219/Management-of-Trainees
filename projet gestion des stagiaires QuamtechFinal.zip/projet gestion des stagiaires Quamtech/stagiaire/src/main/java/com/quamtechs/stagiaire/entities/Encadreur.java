package com.quamtechs.stagiaire.entities;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Encadreur {
    @Id
    private String idEncadreur;
    private String nomEncadreur;
    private String prenomEncadreur;
    private String specialite;
    private String telEncadreur;
    private String emailEncadreur;
    private String password;
    private ArrayList<String> listStag;
}
