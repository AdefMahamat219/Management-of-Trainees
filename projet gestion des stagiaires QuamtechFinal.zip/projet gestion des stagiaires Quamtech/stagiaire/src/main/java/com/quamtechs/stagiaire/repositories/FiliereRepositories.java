package com.quamtechs.stagiaire.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.quamtechs.stagiaire.entities.Filiere;

public interface FiliereRepositories extends MongoRepository<Filiere, String>  {
    
}
