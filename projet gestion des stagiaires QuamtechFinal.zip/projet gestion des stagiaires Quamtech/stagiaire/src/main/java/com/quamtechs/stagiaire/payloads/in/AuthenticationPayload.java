package com.quamtechs.stagiaire.payloads.in;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AuthenticationPayload {
    @NotNull(message = "L'email de l'admin est requise")
    private String emailEncadreur;
    @NotNull(message = "Le mot de passe de l'admin est requis")
    private String password;
}
