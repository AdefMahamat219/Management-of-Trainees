package com.quamtechs.stagiaire.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Data
@Configuration
public class ConfigStagiaire {
    @Value("${idEncadreur}")
    public String idEncadreur;
}
