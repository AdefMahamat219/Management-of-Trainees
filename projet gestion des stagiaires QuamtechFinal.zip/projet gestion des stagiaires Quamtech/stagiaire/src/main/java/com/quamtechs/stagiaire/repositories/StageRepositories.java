package com.quamtechs.stagiaire.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.quamtechs.stagiaire.entities.Stage;

public interface StageRepositories extends MongoRepository<Stage, String> {

}
