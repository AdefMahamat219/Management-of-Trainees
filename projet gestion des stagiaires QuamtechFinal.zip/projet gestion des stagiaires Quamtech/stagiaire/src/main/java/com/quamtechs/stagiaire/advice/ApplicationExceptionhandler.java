package com.quamtechs.stagiaire.advice;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.quamtechs.stagiaire.exceptions.EncadreurNonTrouverException;
import com.quamtechs.stagiaire.exceptions.GestionStagexception;
import com.quamtechs.stagiaire.exceptions.MessagingException;
import com.quamtechs.stagiaire.exceptions.MotDePasseIncorrectException;
import com.quamtechs.stagiaire.exceptions.StagiaireNonTrouverException;
import com.quamtechs.stagiaire.exceptions.UtilisateurAvecEmailException;


@RestControllerAdvice
public class ApplicationExceptionhandler {
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String>gererLesArgumentsInvalid(MethodArgumentNotValidException excep){
        Map<String, String>erroMap = new HashMap<>();
        excep.getBindingResult().getFieldErrors().forEach(erreur ->{
            erroMap.put(erreur.getField(),erreur.getDefaultMessage());
        });
        return erroMap;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(NumberFormatException.class)
    public Map<String, String> gererExceptionsDeType(NumberFormatException excep)
    {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("\u274C Format d'entrée non valid, verifier les champs et reessayer! \u274C ", excep.getMessage());
        return errorMap;
    }


    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(GestionStagexception.class)
    public Map<String, String> gererExceptionsDesSons(GestionStagexception excep)
    {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("Message D'erreur", excep.getMessage());
        return errorMap;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(MessagingException.class)
    public Map<String, String> messagingException(MessagingException excep)
    {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("Message D'erreur", excep.getMessage());
        return errorMap;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(MotDePasseIncorrectException.class)
    public Map<String, String> motDePasseIncorrectException(MotDePasseIncorrectException excep)
    {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("Message D'erreur", excep.getMessage());
        return errorMap;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(EncadreurNonTrouverException.class)
    public Map<String, String> encadreurNonTrouverException(EncadreurNonTrouverException excep)
    {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("Message D'erreur", excep.getMessage());
        return errorMap;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(StagiaireNonTrouverException.class)
    public Map<String, String> stagiaireNonTrouverException(StagiaireNonTrouverException excep)
    {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("Message D'erreur", excep.getMessage());
        return errorMap;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(UtilisateurAvecEmailException.class)
    public Map<String, String> utilisateurAvecEmailException(UtilisateurAvecEmailException excep)
    {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("Message D'erreur", excep.getMessage());
        return errorMap;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(UnsupportedOperationException.class)
    public Map<String, String> gererExceptionsNonSupportées(UnsupportedOperationException excep)
    {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("Message D'erreur", excep.getMessage());
        return errorMap;
    }
    
}
