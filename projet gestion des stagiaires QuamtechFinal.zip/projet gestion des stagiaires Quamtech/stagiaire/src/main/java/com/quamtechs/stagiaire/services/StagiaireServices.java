package com.quamtechs.stagiaire.services;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quamtechs.stagiaire.config.ConfigStagiaire;
import com.quamtechs.stagiaire.entities.Stagiaire;
import com.quamtechs.stagiaire.enumerations.StatutStagiaire;
import com.quamtechs.stagiaire.exceptions.GestionStagexception;
import com.quamtechs.stagiaire.payloads.in.CreerStagiairePayload;
import com.quamtechs.stagiaire.payloads.in.EditStagiairePayload;
import com.quamtechs.stagiaire.repositories.EncadreurRepositories;
import com.quamtechs.stagiaire.repositories.StagiaireRepositories;

import lombok.AllArgsConstructor;
@Service
@AllArgsConstructor
public class StagiaireServices {
    @Autowired
    private final StagiaireRepositories stagiaireRepositories;
    private final EncadreurRepositories encadreurRepositories;
    private ConfigStagiaire configStagiaire;

    public Stagiaire creerStagiaire(CreerStagiairePayload creerStagiairePayload) throws GestionStagexception{
            Stagiaire stagiaire = Stagiaire.builder()
            .idStagiaire(UUID.randomUUID().toString())
            .nom(creerStagiairePayload.getNom())
            .prenom(creerStagiairePayload.getPrenom())
            .dateNaissance(creerStagiairePayload.getDateNaissance())
            .lieuNaissance(creerStagiairePayload.getLieuNaissance())
            .email(creerStagiairePayload.getEmail())
            .etablissement(creerStagiairePayload.getEtablissement())
            .filiere(creerStagiairePayload.getEtablissement())
            .numTel(creerStagiairePayload.getNumTel())
            .typeStage(creerStagiairePayload.getTypeStage())
            .dateInscrip(LocalDate.now())
            .statutStagiaire(StatutStagiaire.EN_COURS_DE_VERIFICATION)
            .build();
            var test = encadreurRepositories.existsById(configStagiaire.getIdEncadreur());
            if (test) {
                stagiaire.setIdEncadreur(configStagiaire.getIdEncadreur());
                var enc = encadreurRepositories.findById(configStagiaire.getIdEncadreur()).get();
                var listStag = enc.getListStag();
                listStag.add(stagiaire.getIdStagiaire());
                enc.setListStag(listStag);
                encadreurRepositories.save(enc);
            } else {
                throw new GestionStagexception(500, "l'encadreur avec pour id : "+configStagiaire.getIdEncadreur()+" n'existe pas !!");
            }
            return stagiaireRepositories.save(stagiaire);
    }

    public String deleteStagiaireById(String id) throws GestionStagexception{
        var test = stagiaireRepositories.existsById(id);
        if (test) {
            var stag = stagiaireRepositories.findById(id).get();
            try {
                    var enc = encadreurRepositories.findById(stag.getIdEncadreur()).get();
                    var list = enc.getListStag();
                    list.remove(id);
                    enc.setListStag(list);
                    encadreurRepositories.save(enc);
                } catch (Exception e) {
                    throw new GestionStagexception(500,"erreur lors de l'extraction du stagiaire chez son ancien encadreur !!");
                }
            stagiaireRepositories.deleteById(id);
            return "le stagiaire avec pour id : "+id+" a été supprimé !!";
        } else {
            throw new GestionStagexception(500,"utilisateur inexistant !!");
        } 
    }


    public String setEncad2Stagiaire(String idStagiaire, String idEncadreur) throws GestionStagexception{
        var testS = stagiaireRepositories.existsById(idStagiaire);
        var testE = encadreurRepositories.existsById(idEncadreur);
        if (testS) {
            if (testE) {
                var stag = stagiaireRepositories.findById(idStagiaire).get();
                try {
                    var enc = encadreurRepositories.findById(stag.getIdEncadreur()).get();
                    var list = enc.getListStag();
                    list.remove(idStagiaire);
                    enc.setListStag(list);
                    encadreurRepositories.save(enc);
                } catch (Exception e) {
                    throw new GestionStagexception(500,"erreur lors de l'extraction du stagiaire chez son ancien encadreur !!");
                }
                stag.setIdEncadreur(idEncadreur);
                stagiaireRepositories.save(stag);
                return "l'encadreur avec pour id : "+idEncadreur +" a été affecté au stagiaire "+ stag.getNom()+stag.getPrenom();
            } else {
                return "l'encadreur avec pour id " +idEncadreur+" n'existe pas dans la base de données";
            }
        } else {
            throw new GestionStagexception(500,"le stagiaire avec pour id : "+idStagiaire+" n'existe pas !!");
        } 
    }

    public Stagiaire changerStatutStagiaire(String id, StatutStagiaire statutStagiaire) throws GestionStagexception{
        var test = stagiaireRepositories.existsById(id);
        if (test) {
            Stagiaire stagiaire = stagiaireRepositories.findById(id).get();
            stagiaire.setStatutStagiaire(statutStagiaire);
            return stagiaireRepositories.save(stagiaire);
        } else {
            throw new GestionStagexception(500,"stagiaire inexistant !!");
        } 
    }

    public Stagiaire findStagiaireById(String id) throws GestionStagexception{
        var test = stagiaireRepositories.existsById(id);
        if (test) {
            return stagiaireRepositories.findById(id).get();
        } else {
            throw new GestionStagexception(500,"utilisateur inexistant !!");
        } 
    }

    public Stagiaire editStagiaire(EditStagiairePayload editStagiairePayload, String id) throws GestionStagexception{
        try {
            Stagiaire stag = findStagiaireById(id);
            stag.setDateNaissance(editStagiairePayload.getDateNaissance());
            stag.setEmail(editStagiairePayload.getEmail());
            stag.setEtablissement(editStagiairePayload.getEtablissement());
            stag.setFiliere(editStagiairePayload.getFiliere());
            stag.setNom(editStagiairePayload.getNom());
            stag.setPrenom(editStagiairePayload.getNom());
            stag.setNumTel(editStagiairePayload.getNumTel());
            return stagiaireRepositories.save(stag);
        } catch (Exception e) {
            throw new GestionStagexception(500,"erreur survenue lors de la modificatio du stagiaire !!");
        }
    }

    public List<Stagiaire>listerTousLesStag() throws GestionStagexception{
         var liste = stagiaireRepositories.findAll();
         if (liste.toString()=="[]") {
            throw new GestionStagexception(500,"aucun stagiaire trouvé !!");
         } else {
            return liste;
         }
    }

    public String deleteAllStag() throws GestionStagexception{
        var stag = stagiaireRepositories.findAll();
        if (stag == null||stag.isEmpty()||stag.contains(null)) {
            throw new GestionStagexception(500,"aucun stagiaire trouvé !!");
        } else {
            stagiaireRepositories.deleteAll();
            return "tous les stagiaires ont été supprimés !! ";
        }
    }

    public List<Stagiaire> stagiairesNonTraiter()
    {
        var stagiaires = stagiaireRepositories.findAll();
        return stagiaires.stream()
                     .filter(stagiaire -> stagiaire.getStatutStagiaire().equals(StatutStagiaire.EN_COURS_DE_VERIFICATION))
                     .collect(Collectors.toList());
    }

    public List<Stagiaire> stagiairesAdmis() {
        var stagiaires = stagiaireRepositories.findAll();
        return stagiaires.stream()
                     .filter(stagiaire -> stagiaire.getStatutStagiaire().equals(StatutStagiaire.ACCEPTE))
                     .collect(Collectors.toList());
    }
}
