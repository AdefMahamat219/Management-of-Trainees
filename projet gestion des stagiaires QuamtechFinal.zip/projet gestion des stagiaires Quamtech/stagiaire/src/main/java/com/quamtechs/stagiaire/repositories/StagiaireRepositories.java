package com.quamtechs.stagiaire.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.quamtechs.stagiaire.entities.Stagiaire;
import java.util.List;
import java.util.Optional;


public interface StagiaireRepositories extends MongoRepository<Stagiaire, String> {
    Stagiaire findByEmail(String email);
}
