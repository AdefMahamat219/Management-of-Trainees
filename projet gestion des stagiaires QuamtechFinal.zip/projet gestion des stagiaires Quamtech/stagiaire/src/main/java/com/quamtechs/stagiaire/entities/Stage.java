package com.quamtechs.stagiaire.entities;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;

import com.quamtechs.stagiaire.enumerations.TypeStage;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Stage {
    @Id
    private String idStage;
    private TypeStage typeStage;
    private LocalDate dateDebut;
    private LocalDate dateFin;
    private String theme;
    private String evaluation;
}
