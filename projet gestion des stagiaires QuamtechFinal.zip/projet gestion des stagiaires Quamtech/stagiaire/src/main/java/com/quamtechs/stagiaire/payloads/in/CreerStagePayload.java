package com.quamtechs.stagiaire.payloads.in;

import java.time.LocalDate;

import com.quamtechs.stagiaire.enumerations.TypeStage;

import jakarta.validation.constraints.NotNull;

public class CreerStagePayload {
    @NotNull(message = "le type est requis !!")
    private TypeStage typeStage;

    @NotNull(message = "la date de debut est requise !!")
    private LocalDate dateDebut;

    @NotNull(message = "la date de fin est requise !!")
    private LocalDate dateFin;

    @NotNull(message = "le theme est requis !!")
    private String theme;

    @NotNull(message = "l'evaluation est requise !!")
    private String evaluation;
}
