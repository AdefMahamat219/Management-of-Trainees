package com.quamtechs.stagiaire.payloads.in;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class EditEncadreur {
    @NotNull(message = "le nom est requis !!")
    private String nomEncadreur;

    @NotNull(message = "le prenom est requis !!")
    private String prenomEncadreur;

    @NotNull(message = "la fonction est requise !!")
    private String Specialite;

    @NotNull(message = "le contact est requis !!")
    private String telEncadreur;

    @NotNull(message = "le mail est requis !!")
    private String emailEncadreur;
}
