package com.quamtechs.stagiaire.enumerations;

public enum TypeStage {
    PRO,
    ACC
}
