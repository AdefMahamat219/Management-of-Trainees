package com.quamtechs.stagiaire.payloads.in;

import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Document
public class CreerFiliairePayload {
    @NotNull(message = "le nom est requis !!")
    private String nomFil; 

    @NotNull(message = "le niveau est requis !!")
    private String niv; 
}
