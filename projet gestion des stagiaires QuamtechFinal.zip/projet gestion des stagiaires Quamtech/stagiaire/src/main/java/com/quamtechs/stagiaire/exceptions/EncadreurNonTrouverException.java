package com.quamtechs.stagiaire.exceptions;

public class EncadreurNonTrouverException extends Exception{
    public EncadreurNonTrouverException(String msg)
    {
        super(msg);
    }
}
