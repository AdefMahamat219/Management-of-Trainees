package com.quamtechs.stagiaire.exceptions;

public class StagiaireNonTrouverException extends Exception{
    public StagiaireNonTrouverException(String msg)
    {
        super(msg);
    }
}
