package com.quamtechs.stagiaire.exceptions;

public class UtilisateurAvecEmailException extends Exception {
    public UtilisateurAvecEmailException(String msg){
        super(msg);
    }
}
