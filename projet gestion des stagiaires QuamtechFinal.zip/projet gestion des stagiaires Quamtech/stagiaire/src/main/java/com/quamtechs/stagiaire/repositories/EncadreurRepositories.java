package com.quamtechs.stagiaire.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.quamtechs.stagiaire.entities.Encadreur;
import java.util.List;


public interface EncadreurRepositories extends MongoRepository<Encadreur, String> {
    Encadreur findByEmailEncadreur(String emailEncadreur);
}
