package com.quamtechs.stagiaire.exceptions;

public class MotDePasseIncorrectException extends Exception {
    public MotDePasseIncorrectException(String msg){
        super(msg);
    }
}
