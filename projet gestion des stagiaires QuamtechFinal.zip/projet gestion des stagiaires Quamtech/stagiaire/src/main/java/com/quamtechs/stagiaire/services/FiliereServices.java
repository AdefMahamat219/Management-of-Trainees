package com.quamtechs.stagiaire.services;

import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.quamtechs.stagiaire.entities.Filiere;
import com.quamtechs.stagiaire.exceptions.GestionStagexception;
import com.quamtechs.stagiaire.payloads.in.CreerFiliairePayload;
import com.quamtechs.stagiaire.repositories.FiliereRepositories;

import lombok.AllArgsConstructor;
@Service
@AllArgsConstructor
public class FiliereServices {
    private final FiliereRepositories filiereRepositories;

    public Filiere creerFiliere(CreerFiliairePayload creerFiliairePayload) throws GestionStagexception{
        try {
            Filiere filiere = Filiere.builder()
            .nomFil(creerFiliairePayload.getNomFil())
            .niv(creerFiliairePayload.getNiv())
            .idFil(UUID.randomUUID().toString())
            .build();
            return filiereRepositories.save(filiere);
        } catch (Exception e) {
            throw new GestionStagexception(500, "erreur survenue lors de l'enregistrement de la filiere !! ");
        }
    }

    public String deleteFiliereById(String id) throws GestionStagexception{
        var test = filiereRepositories.existsById(id);
        if (test) {
            filiereRepositories.deleteById(id);
            return "la filiere avec pour id : "+id+" a été supprimé !!";
        } else {
            throw new GestionStagexception(500,"filiere inexistante !!");
        } 
    }

    public Filiere findFiliereById(String id) throws GestionStagexception{
        var test = filiereRepositories.existsById(id);
        if (test) {
            return filiereRepositories.findById(id).get();
        } else {
            throw new GestionStagexception(500,"filiere inexistante !!");
        } 
    }

    public List<Filiere>listerTousLesFil() throws GestionStagexception{
         var liste = filiereRepositories.findAll();
         if (liste.toString()=="[]") {
            throw new GestionStagexception(500,"aucune filiere trouvée !!");
         } else {
            return liste;
         }
    }

    public String deleteAllFil() throws GestionStagexception{
        var stag = filiereRepositories.findAll();
        if (stag == null||stag.isEmpty()||stag.contains(null)) {
            throw new GestionStagexception(500,"aucune filiere trouvée !!");
        } else {
            filiereRepositories.deleteAll();
            return "toutes les filieres ont étées supprimées !! ";
        }
    }
}
