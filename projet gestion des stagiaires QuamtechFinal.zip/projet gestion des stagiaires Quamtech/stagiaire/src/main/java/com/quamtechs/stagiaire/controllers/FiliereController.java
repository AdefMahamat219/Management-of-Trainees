package com.quamtechs.stagiaire.controllers;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quamtechs.stagiaire.entities.Filiere;
import com.quamtechs.stagiaire.exceptions.GestionStagexception;
import com.quamtechs.stagiaire.payloads.in.CreerFiliairePayload;
import com.quamtechs.stagiaire.services.FiliereServices;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@RequestMapping(value = "/filiere")
public class FiliereController {
    private final FiliereServices filiereServices;

    @PostMapping(value = "/creerFiliere")
    public ResponseEntity<Filiere> creerFiliere(@Valid @RequestBody CreerFiliairePayload creerFiliairePayload ) throws GestionStagexception{
        var filiere = filiereServices.creerFiliere(creerFiliairePayload);
        return new ResponseEntity<Filiere>(filiere, HttpStatus.CREATED);
    }

    @DeleteMapping(value = "/supprimerFiliereById")
    public ResponseEntity<String> supprimerStagiaireById( String idfliere) throws GestionStagexception{
        var filiere = filiereServices.deleteFiliereById(idfliere);
        return new ResponseEntity<String>(filiere, HttpStatus.OK);
    }

    @GetMapping(value = "/findOneFiliereById")
    public ResponseEntity<Filiere>findOneStagiaireById(String idfliere) throws GestionStagexception {
      return ResponseEntity.ok(filiereServices.findFiliereById(idfliere));
    }

    @DeleteMapping(value = "/deleteAllFil")
    public ResponseEntity<String> deleteAllFil() throws GestionStagexception{
        return new ResponseEntity<String>(filiereServices.deleteAllFil(), HttpStatus.OK);
    }

    @GetMapping(value = "/findAllFil")
    public ResponseEntity<List<Filiere>> findAllFil() throws GestionStagexception {
      return ResponseEntity.ok(filiereServices.listerTousLesFil());
    }
}
