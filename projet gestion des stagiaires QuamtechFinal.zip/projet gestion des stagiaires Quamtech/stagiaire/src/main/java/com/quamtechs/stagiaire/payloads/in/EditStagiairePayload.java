package com.quamtechs.stagiaire.payloads.in;

import java.time.LocalDate;


import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
public class EditStagiairePayload {
    @NotNull(message = "le nom est requis !!")
    private String nom;

    @NotNull(message = "le prenom est requis !!")
    private String prenom;

    @NotNull(message = "la date de naissance est requise !!")
    private LocalDate dateNaissance;

    @NotNull(message = "le mot de passe est requis !!")
    private String password;

    @NotNull(message = "la filiere est requise !!")
    private String filiere;

    @NotNull(message = "l'etablissement est requis !!")
    private String etablissement;

    @NotNull(message = "le mail est requis !!")
    private String email;

    @NotNull(message = "le numero de telephione est requis !!")
    private String numTel;
}
