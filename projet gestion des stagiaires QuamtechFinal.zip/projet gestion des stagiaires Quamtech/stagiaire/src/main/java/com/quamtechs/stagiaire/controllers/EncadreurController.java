package com.quamtechs.stagiaire.controllers;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.quamtechs.stagiaire.entities.Encadreur;
import com.quamtechs.stagiaire.exceptions.EncadreurNonTrouverException;
import com.quamtechs.stagiaire.exceptions.GestionStagexception;
import com.quamtechs.stagiaire.exceptions.MessagingException;
import com.quamtechs.stagiaire.exceptions.MotDePasseIncorrectException;
import com.quamtechs.stagiaire.exceptions.StagiaireNonTrouverException;
import com.quamtechs.stagiaire.exceptions.UtilisateurAvecEmailException;
import com.quamtechs.stagiaire.payloads.in.AuthenticationPayload;
import com.quamtechs.stagiaire.payloads.in.CreerEncadreurpayload;
import com.quamtechs.stagiaire.payloads.in.EditEncadreur;
import com.quamtechs.stagiaire.services.EncadreurServices;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@CrossOrigin("*")
@RequestMapping(value = "/encadreur")
public class EncadreurController {
    private final EncadreurServices encadreurServices;

    @PostMapping(value = "/creerEncadreur")
    public ResponseEntity<Encadreur> créerStagiaire(@Valid @RequestBody CreerEncadreurpayload creerEncadreurpayload ) throws GestionStagexception, UtilisateurAvecEmailException{
        var encadreur = encadreurServices.creerEncadreur(creerEncadreurpayload);
        return new ResponseEntity<Encadreur>(encadreur, HttpStatus.CREATED);
    }

    @GetMapping(value = "/envoiEmailValidation")
    public ResponseEntity<String> envoieValidationEmail(@RequestParam("emailStagiaire") String emailStagiaire) throws GestionStagexception, UnsupportedEncodingException, MessagingException, jakarta.mail.MessagingException, StagiaireNonTrouverException {
      
      encadreurServices.envoiEmailValidation(emailStagiaire);
      String confirm = "Email envoyé vers "+emailStagiaire+" avec succès";
      return new ResponseEntity<String>(confirm, HttpStatus.ACCEPTED);
    }

    @GetMapping(value = "/envoiEmailRefuser")
    public ResponseEntity<String> envoieEmailRefuser(@RequestParam("emailStagiaire") String emailStagiaire) throws GestionStagexception, UnsupportedEncodingException, MessagingException, jakarta.mail.MessagingException, StagiaireNonTrouverException {
      
      encadreurServices.envoiEmailRefuser(emailStagiaire);
      String confirm = "Email envoyé vers "+emailStagiaire+" avec succès";
      return new ResponseEntity<String>(confirm, HttpStatus.ACCEPTED);
    }

    @PostMapping(value = "/authEncadreur")
    public ResponseEntity<String> authentificationEncadreur(@Valid @RequestBody AuthenticationPayload authenticationPayload) throws MotDePasseIncorrectException, EncadreurNonTrouverException
    {
      String response =  encadreurServices.authentificationManuelle(authenticationPayload);
      return new ResponseEntity<String>(response, HttpStatus.ACCEPTED);
    }

    @DeleteMapping(value = "/supprimerencadredeurById")
    public ResponseEntity<String> supprimerencadredeurById( String idencadredeur) throws GestionStagexception{
        var encadreur = encadreurServices.deleteEncadreurById(idencadredeur);
        return new ResponseEntity<String>(encadreur, HttpStatus.OK);
    }

    @GetMapping(value = "/findOneencadredeurById")
    public ResponseEntity<Encadreur>findOneencadredeurById(String idencadredeur) throws GestionStagexception {
      return ResponseEntity.ok(encadreurServices.findEncadreurById(idencadredeur));
    }

    @GetMapping(value = "/findAllStagEncById")
    public ResponseEntity<ArrayList<String>>findAllStagEncById(String idencadredeur) throws GestionStagexception {
      return ResponseEntity.ok(encadreurServices.findAllStagEncById(idencadredeur));
    }

    @PutMapping("/editEncadreur")
    public ResponseEntity<Encadreur> editEncadreur(EditEncadreur editEncadreur, String idEncadreur) throws GestionStagexception{
        Encadreur res = encadreurServices.editEnc(editEncadreur, idEncadreur);
        return new ResponseEntity<Encadreur>(res, HttpStatus.OK);
    }

    @DeleteMapping(value = "/deleteAllEnc")
    public ResponseEntity<String> deleteAllEnc() throws GestionStagexception{
        var stagiaire = encadreurServices.deleteAllEnc();
        return new ResponseEntity<String>(stagiaire, HttpStatus.OK);
    }

    @GetMapping(value = "/findAllEnc")
    public ResponseEntity<List<Encadreur>> findAllEnc() throws GestionStagexception {
      return ResponseEntity.ok(encadreurServices.listerTousLesEnc());
    }
}
