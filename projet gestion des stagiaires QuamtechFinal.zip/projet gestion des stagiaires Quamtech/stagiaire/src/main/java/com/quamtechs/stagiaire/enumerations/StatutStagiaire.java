package com.quamtechs.stagiaire.enumerations;

public enum StatutStagiaire {
    ACCEPTE,
    REFUSE,
    EN_COURS_DE_VERIFICATION
}
