package com.quamtechs.stagiaire.exceptions;

public class GestionStagexception extends Exception {
    public GestionStagexception(int code, String message){
        super(message);
    }
}
